<?php

class Mds_View extends \Mds\Prestashop\Helpers\View {}
class Mds_ColliveryApi extends \Mds\Prestashop\Collivery\ColliveryApi {}
class Mds_Install extends \Mds\Prestashop\Installer\Install {}
class Mds_Uninstall extends \Mds\Prestashop\Installer\Uninstall {}
class Mds_Services extends \Mds\Prestashop\Settings\Services {}
class Mds_Surcharge extends Mds\Prestashop\Settings\Surcharge {}
class Mds_RiskCover extends \Mds\Prestashop\Settings\RiskCover {}
class Mds_SettingsService extends \Mds\Prestashop\Settings\SettingsService {}
