<?php namespace Mds\Prestashop\Exceptions;

class InvalidData extends ColliveryException {}
