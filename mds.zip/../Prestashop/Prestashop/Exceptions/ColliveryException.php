<?php namespace Mds\Prestashop\Exceptions;

class ColliveryException extends \RuntimeException {}
