<?php namespace Mds\Prestashop\Exceptions;

class UnableToRegisterHook extends ColliveryException {}
