<?php namespace Mds\Prestashop\Exceptions;

class UnableToUpdateConfiguration extends ColliveryException {}
